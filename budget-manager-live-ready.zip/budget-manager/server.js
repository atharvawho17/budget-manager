require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');

const { pool } = require('./src/config/db');
const authenticate = require('./src/middleware/auth');
const errorHandler = require('./src/middleware/errorHandler');
const { HttpError } = require('./src/utils/httpError');

// ---- Fail fast on a missing / placeholder JWT secret ----
const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 16 || secret === 'replace_with_a_long_random_string') {
  console.error('JWT_SECRET is missing or still the placeholder. Set a long random value in your .env file.');
  process.exit(1);
}

const app = express();
app.disable('x-powered-by');

// ---- CORS: only the origins listed in CLIENT_ORIGIN may call the API from a browser ----
const allowedOrigins = (process.env.CLIENT_ORIGIN || '').split(',').map((s) => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => cb(null, !origin || allowedOrigins.includes(origin)),
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  next();
});
app.use(express.json({ limit: '5mb' }));

// ---- REST API ----
app.get('/api/health', async (req, res, next) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok' }); } catch (err) { next(err); }
});
app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/transactions', authenticate, require('./src/routes/transactions'));
app.use('/api/budgets', authenticate, require('./src/routes/budgets'));
app.use('/api/profile', authenticate, require('./src/routes/profile'));
app.use('/api/dashboard', authenticate, require('./src/routes/dashboard'));
app.use('/api/reports', authenticate, require('./src/routes/reports'));
app.use('/api/data', authenticate, require('./src/routes/data'));
app.use('/api', (req, res, next) => next(new HttpError(404, 'API route not found.')));

// ---- Frontend (static files) ----
app.use(express.static(path.join(__dirname, 'public')));

app.use(errorHandler);

const PORT = Number(process.env.PORT) || 3000;
pool.query('SELECT 1')
  .then(() => {
    app.listen(PORT, () => console.log(`Budget Manager running at http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error(`Could not connect to MySQL: ${err.message}`);
    console.error('Check DB_* values in .env and that you have run the schema (npm run db:init).');
    process.exit(1);
  });
