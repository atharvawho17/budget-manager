-- Budget Manager database schema (MySQL 8.0+)
-- Run:  mysql -u root -p < schema.sql      (or: npm run db:init)

CREATE DATABASE IF NOT EXISTS budget_manager
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE budget_manager;

-- 1. users ---------------------------------------------------------------
-- token_version is bumped on logout / password change, which invalidates
-- every JWT issued earlier for that user.
CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username       VARCHAR(50)  NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  token_version  INT UNSIGNED NOT NULL DEFAULT 0,
  created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB;

-- 2. user_settings (one row per user) -------------------------------------
CREATE TABLE IF NOT EXISTS user_settings (
  user_id         INT UNSIGNED  NOT NULL,
  display_name    VARCHAR(100)  NOT NULL DEFAULT '',
  monthly_budget  DECIMAL(12,2) NOT NULL DEFAULT 1000.00,
  updated_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  CONSTRAINT fk_settings_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT chk_settings_budget CHECK (monthly_budget >= 0)
) ENGINE=InnoDB;

-- 3. budgets (one row per user per expense category) ----------------------
CREATE TABLE IF NOT EXISTS budgets (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id       INT UNSIGNED  NOT NULL,
  category      VARCHAR(50)   NOT NULL,
  limit_amount  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  updated_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_budget_user_category (user_id, category),
  CONSTRAINT fk_budgets_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT chk_budget_limit CHECK (limit_amount >= 0)
) ENGINE=InnoDB;

-- 4. transactions (income + expenses) -------------------------------------
CREATE TABLE IF NOT EXISTS transactions (
  id           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id      INT UNSIGNED  NOT NULL,
  type         ENUM('income','expense') NOT NULL,
  description  VARCHAR(255)  NOT NULL,
  amount       DECIMAL(12,2) NOT NULL,
  category     VARCHAR(50)   NOT NULL,
  txn_date     DATE          NOT NULL,
  created_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_tx_user_date (user_id, txn_date),
  KEY idx_tx_user_type_category (user_id, type, category),
  CONSTRAINT fk_tx_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT chk_tx_amount CHECK (amount > 0)
) ENGINE=InnoDB;
